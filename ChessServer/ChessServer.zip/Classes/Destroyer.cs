﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessServer.Classes
{
    static class Destroyer
    {
        public static void Destroy(Game g)
        {
            g = null;
        }
    }
}
